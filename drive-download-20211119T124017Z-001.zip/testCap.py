import sys
print('Number of arguments:', len(sys.argv), 'arguments.')
if len(sys.argv) > 2:
    print('Argument List:', str(sys.argv[2]))